package ru.job4j.lambda;

import java.util.Arrays;
import java.util.Optional;

public class OptionalIfPresent {

    public static void ifPresent(int[] data) {
        max(data).ifPresent(s -> System.out.println("Max: " + max(data).get()));
    }

    private static Optional<Integer> max(int[] data) {
        int max;
        if (data.length == 0) {
            return Optional.empty();
        } else {
            max = data[0];
            for (int i = 1; i < data.length; i++) {
                if (data[i] > max) {
                    max = data[i];
                }
            }
        }
        return Optional.of(max);
    }
}
