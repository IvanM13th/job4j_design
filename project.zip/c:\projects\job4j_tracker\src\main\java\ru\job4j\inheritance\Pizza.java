package ru.job4j.inheritance;

public class Pizza {
    public String name() {
        return "Just tasty pizza";
    }
}
