package ru.job4j.poly;

public interface Animal {
    void sound();
}
