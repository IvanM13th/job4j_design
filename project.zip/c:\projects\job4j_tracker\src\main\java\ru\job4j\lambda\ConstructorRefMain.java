package ru.job4j.lambda;

public class ConstructorRefMain {
    public static void main(String[] args) {
        // создали ссылку на конструктор,
        // переменную можно использовать для создания объкета класса
        FuncInterface modelConstructor = Model::new;
        Model model = modelConstructor.function("Example");
        System.out.println("Значение равно: " + model.getName());
    }
}
