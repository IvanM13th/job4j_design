package ru.job4j.poly;

public interface Vehicle {
    void move();
}
